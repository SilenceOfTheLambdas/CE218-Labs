package game;

import utilities.Action;

public interface Controller {
    Action action();
}
