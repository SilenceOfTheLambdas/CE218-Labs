package utilities;

public class Action {
    public int thrust = 0; // 0 = OFF, 1 = ON
    public int turn = 0; // -1 = LEFT TURN, 0 = OFF, 1 = RIGHT TURN
    public boolean shoot = false; // IF TRUE SHOOT, else DO NOT
}
