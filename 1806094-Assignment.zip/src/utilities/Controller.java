package utilities;

public interface Controller {
    Action action();
}
